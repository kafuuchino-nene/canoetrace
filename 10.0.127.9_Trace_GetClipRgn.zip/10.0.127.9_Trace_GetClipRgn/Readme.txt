Template Readme.txt
==========================================
Hotfix CANoe 10.0.127.9 (SP7)
========================================== 
1. Purpose 
--------------
This hotfix fixes a drawing problem in trace window header and trace tooltip which was introduced by a windows update.


2. Installation for 32 bit program installations 
------------------------------------------------------------
- Rename the following files in the Exec32 folder
  distribInfo.dll 
  CCTrace.dll 
  CCUtils.dll 
- Copy these files provided in the Exec32 folder of this hotfix into the Exec32 folder of the program 
  distribInfo.dll (10.0.127.9) 
  CCTrace.dll (10.0.127.9) 
  CCUtils.dll (10.0.127.9) 

3. Installation for 64 bit program installations 
------------------------------------------------------------
- Rename the following files in the Exec64 folder 
  distribInfo.dll
  CCTrace.dll
  CCUtils.dll 
- Rename the following files in the Exec32 folder
  distribInfo.dll 
- Copy these files provided in the Exec64 folder of this hotfix into the Exec64 folder of the program 
  distribInfo.dll (10.0.127.9)
  CCTrace.dll (10.0.127.9)
  CCUtils.dll (10.0.127.9)
- Copy these files provided in the Exec32 folder of this hotfix into the Exec32 folder of the program 
  distribInfo.dll (10.0.127.9)
